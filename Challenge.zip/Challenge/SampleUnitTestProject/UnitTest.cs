﻿using System;
using Sample;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SampleUnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        private Client _Client;
        [TestInitialize]
        public void SetUp()
        {
            _Client = new Client();
        }

        [TestMethod]
        public void TestWhenAllValuesAreValid()
        {
            //Arrange
           // Client _Client = new Client();
            //Act
            var createInvoiceResult = _Client.CreateInvoice("test", 2, "testRadha");
            bool result = createInvoiceResult.Success;
            //Assert
            Assert.AreEqual(true, result, "Invoice Created");
        }
        [TestMethod]
        public void TestWhenStockIsEmptyString()
        {
            //Act
            var createInvoiceResult = _Client.CreateInvoice("", 2, "testRadha");
            bool result = createInvoiceResult.Success;
            //Assert
            Assert.AreEqual(false, result, "Invoice Not Created");
        }

        [TestMethod]
        public void TestWhenQuantityIsZero()
        {

            //Act
            var createInvoiceResult = _Client.CreateInvoice("Test", 0, "testRadha");
            bool result = createInvoiceResult.Success;
            //Assert
            Assert.AreEqual(false, result, "Invoice Not Created");
        }

        [TestMethod]
        public void TestWhenQuantityIsNegative()
        {

            //Act
            var createInvoiceResult = _Client.CreateInvoice("Test", -2, "testRadha");
            bool result = createInvoiceResult.Success;
            //Assert
            Assert.AreEqual(false, result, "Invoice Not Created");
        }

        [TestMethod]
        public void TestWhenCustomerNameIsEmpty()
        {

            //Act
            var createInvoiceResult = _Client.CreateInvoice("Test", 2, "");
            bool result = createInvoiceResult.Success;
            //Assert
            Assert.AreEqual(false, result, "Invoice Not Created");
        }
    }
}
