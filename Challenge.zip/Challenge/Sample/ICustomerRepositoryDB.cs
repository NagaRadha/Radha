﻿

namespace Sample
{
    public interface ICustomerRepositoryDB
    {
        Customer GetByName(string name);
    }
}
