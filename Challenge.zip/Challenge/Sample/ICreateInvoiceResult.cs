﻿
namespace Sample
{
    public interface ICreateInvoiceResult
    {
        bool Success { get; set; }
    }
}
