﻿

namespace Sample
{
    public interface IInvoice
    {

        int ID { get; set; }
        string StockCode { get; set; }
        int Quantity { get; set; }
        int CustomerID { get; set; }

    }
}
