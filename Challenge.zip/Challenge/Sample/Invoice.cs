﻿namespace Sample
{
    public class Invoice: IInvoice
    {
        public int ID { get; set; }
        public string StockCode { get; set; }
        public int Quantity { get; set; }
        public int CustomerID { get; set; }
    }
}
