﻿namespace Sample
{
    public class CreateInvoiceResult: ICreateInvoiceResult
    {
        public CreateInvoiceResult(bool success)
        {
            Success = success;
        }
        public bool Success { get;  set; }
        //public bool Success { get; private set; }
    }
}
