﻿namespace Sample
{
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName = "App.IPartSupplierService")]
    public interface IAvailabilityService
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://tempuri.org/IAvailabilityService/GetAvailability", ReplyAction = "http://tempuri.org/IPartSupplierService/GetAvailabilityResponse")]
        int GetAvailability(string StockCode);
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface IAvailabilityServiceChannel : Sample.IAvailabilityService, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class AvailabilityServiceClient : System.ServiceModel.ClientBase<Sample.IAvailabilityService>, Sample.IAvailabilityService
    {

        public AvailabilityServiceClient()
        {
        }

        public AvailabilityServiceClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
        }

        public AvailabilityServiceClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public AvailabilityServiceClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
        }

        public AvailabilityServiceClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        public int GetAvailability(string stockCode)
        {
            return base.Channel.GetAvailability(stockCode);
        }
    }
}
