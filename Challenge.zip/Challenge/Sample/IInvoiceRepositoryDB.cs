﻿

namespace Sample
{
    public interface IInvoiceRepositoryDB
    {
        void Add(IInvoice invoice);
    }
}
