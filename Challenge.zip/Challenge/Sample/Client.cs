﻿using Microsoft.Practices.Unity;
namespace Sample
{
    public class Client
    {
        private InvoiceController __Controller;

        public Client()
        {
            IUnityContainer objcontainer = new UnityContainer();
            objcontainer.RegisterType<ICreateInvoiceResult, CreateInvoiceResult>(new InjectionConstructor(false));
            objcontainer.RegisterType<ICustomerRepositoryDB, CustomerRepositoryDB>();
            objcontainer.RegisterType<IInvoice, Invoice>();
            objcontainer.RegisterType<IInvoiceRepositoryDB, InvoiceRepositoryDB>();
            objcontainer.RegisterType<IAvailabilityService, AvailabilityServiceClient>(new InjectionConstructor());
            __Controller = objcontainer.Resolve<InvoiceController>();
          //  __Controller = new InvoiceController();
        }

        public CreateInvoiceResult CreateInvoice(string stockCode, int quantity, string customerName)
        {
            return __Controller.CreateInvoice(stockCode, quantity, customerName);
        }
    }
}
