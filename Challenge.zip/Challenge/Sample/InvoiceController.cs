﻿namespace Sample
{
    public class InvoiceController
    {

        private readonly ICustomerRepositoryDB _CustomerRepository;
        private readonly IInvoiceRepositoryDB _InvoiceRepository;
        private readonly ICreateInvoiceResult _createInvoiceResult;
        private readonly IInvoice _InVoice;
        private readonly IAvailabilityService _Available;


        public InvoiceController(CustomerRepositoryDB customerRepository, InvoiceRepositoryDB invoiceRepository, CreateInvoiceResult createInvoiceResult, Invoice inVoice, AvailabilityServiceClient avaiLable)
        {
            _CustomerRepository = customerRepository;
            _InvoiceRepository = invoiceRepository;
            _createInvoiceResult = createInvoiceResult;
            _InVoice = inVoice;
            _Available = avaiLable;
        }
        public CreateInvoiceResult CreateInvoice(string stockCode, int quantity, string customerName)
        {
            if (string.IsNullOrEmpty(stockCode))
            {
                _createInvoiceResult.Success = false;
                return (CreateInvoiceResult)_createInvoiceResult;
            }

            if (quantity <= 0)
            {
                _createInvoiceResult.Success = false;
                return (CreateInvoiceResult)_createInvoiceResult;
            }
            
            ICustomer _Customer = _CustomerRepository.GetByName(customerName);
            if (_Customer.ID <= 0)
            {
                _createInvoiceResult.Success = false;
                return (CreateInvoiceResult)_createInvoiceResult;
            }
            
            int _Availability = _Available.GetAvailability(stockCode);
            if (_Availability <= 0)
            {
                _createInvoiceResult.Success = false;
                return (CreateInvoiceResult)_createInvoiceResult;
            }
            
            _InVoice.StockCode = stockCode;
            _InVoice.Quantity = quantity;
            _InVoice.CustomerID = _Customer.ID;
            
            _InvoiceRepository.Add(_InVoice);
            _createInvoiceResult.Success = true;
            return (CreateInvoiceResult)_createInvoiceResult;
        }
    }
}
